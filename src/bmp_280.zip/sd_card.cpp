#include <Arduino.h>
#include "sd_card.h"


void sd_setup()
{
    Serial.println("Initializing sd card...");
    if(!SD.begin(CHIP_SELECT)) {
        Serial.println("Error of initializing sd card");
        return;
    }
    Serial.println("Initializing compelete\n\n");
}

void sd_log(double T, double P, double A)
{
    File file = SD.open(FILENAME, FILE_WRITE);

    if(file){
        file.print("T = ");file.print(T,2); file.print("degC\t");
        file.print("P = ");file.print(P,2); file.print("mBar\t");
        file.print("A = ");file.print(A,2); file.println("m");
    }

    file.close();
}
/*



void loop() {
  double T,P; //T - temperatura    P - cisnienie
  char result = bmp.startMeasurment();
 
  if(result!=0){
    delay(result);
    result = bmp.getTemperatureAndPressure(T,P);
    P+=26.50;
      if(result!=0)
      {
        double A = bmp.altitude(P,P0);
        file1 = SD.open(FILENAME, FILE_WRITE);
        if(file1){
        #ifdef SDCARD
          file1.print("T = ");file1.print(T,2); file1.print("degC\t");
          file1.print("P = ");file1.print(P,2); file1.print("mBar\t");
          file1.print("A = ");file1.print(A,2); file1.println("m");
        #else 
          Serial.print("T = ");Serial.print(T,2); Serial.print("degC\t");
          Serial.print("P = ");Serial.print(P,2); Serial.print("mBar\t");
          Serial.print("A = ");Serial.print(A,2); Serial.println("m");
        #endif
        }
       
      }
      else {
        Serial.println("Blad pomiaru.");
      }
  }
  else {
    Serial.println("Blad pomiaru.");
  }
  file1.close();
  delay(1000);
}

void sd_read_everything()
{
  file1 = SD.open("text.txt");
  if(file1){
    while(file1.available())
    {
      Serial.write(file1.read());
    }
  }
  file1.close();
}*/